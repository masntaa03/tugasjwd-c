<?php
$servername = "localhost";
$database = "id21079405_vsga";
$username = "id21079405_projectta6";
$password = "4yc8ry$N";
$conn = mysqli_connect($servername, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>